@echo [%time%]=========Install RST driver========= 

pnputil /add-driver "%~dp0Drivers\*.inf" /install 

@echo [%time%]=========RST driver Install Complete========= 
