@echo [%time%]=========Install ME driver========= 

pnputil /add-driver "%~dp0Drivers\MEI\win10\*.inf" /install 
pnputil /add-driver "%~dp0Drivers\OemExtension\*.inf" /install 
pnputil /add-driver "%~dp0Drivers\JHI\win10\*.inf" /install 
pnputil /add-driver "%~dp0Drivers\ICLS\*.inf" /install 

@echo [%time%]=========ME Install Complete========= 
